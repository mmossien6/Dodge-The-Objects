/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 gamescreen gamescreen.png 
 * Time-stamp: Wednesday 04/01/2020, 17:25:52
 * 
 * Image Information
 * -----------------
 * gamescreen.png 80@151
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMESCREEN_H
#define GAMESCREEN_H

extern const unsigned short gamescreen[12080];
#define GAMESCREEN_SIZE 24160
#define GAMESCREEN_LENGTH 12080
#define GAMESCREEN_WIDTH 80
#define GAMESCREEN_HEIGHT 151

#endif

