HW8 - Mark Edward Mossien

DODGE THE OBJECTS - readme

- A game where you are a square, and you must dodge the objects!
- Use the arrow keys to move Up, Down, Left, Right
- You can't win, so try to maximize your score by lasting as long as possible!
- Enjoy! Press Enter to begin, and Backspace to return to the start screen at any point in the game.