/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 losescreen losescreen.png 
 * Time-stamp: Wednesday 04/01/2020, 17:25:27
 * 
 * Image Information
 * -----------------
 * losescreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSESCREEN_H
#define LOSESCREEN_H

extern const unsigned short losescreen[38400];
#define LOSESCREEN_SIZE 76800
#define LOSESCREEN_LENGTH 38400
#define LOSESCREEN_WIDTH 240
#define LOSESCREEN_HEIGHT 160

#endif

